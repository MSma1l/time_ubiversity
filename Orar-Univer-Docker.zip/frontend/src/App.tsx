import { useEffect, useMemo, useState } from 'react'
import { demoLessons, lessonMatchesWeek, weekdayNames, weekTypeFor } from './schedule'
import { initializeTelegram } from './telegram'
import type { AppNotification, Lesson, Role, WeekType } from './types'
import { createTeacherGroup, createTeacherStudent, deleteLessonRemote, loadAccount, loadTeacherGroups, loadTeacherStudents, markNotificationsRead, saveAttendance, saveLabGrade, saveLessonRemote, updateLessonRemote, updateProfileState, updateRole, type TeacherGroup, type TeacherStudent } from './api'

const roleLabels: Record<Role, string> = { student: 'Student', teacher: 'Profesor' }
const demoNotifications: AppNotification[] = [{ id: 1, kind: 'system', title: 'Bine ai venit în Orar Univer', body: 'Configurează orele și vei primi memento-uri direct în Telegram.', readAt: null, createdAt: new Date().toISOString() }]
const weekdayIndex = (date: Date) => (date.getDay() + 6) % 7

export function App() {
  const [now, setNow] = useState(() => new Date())
  const todayIndex = weekdayIndex(now)
  const [role, setRole] = useState<Role>('student')
  const [activeDay, setActiveDay] = useState(todayIndex)
  const [week, setWeek] = useState<WeekType>(() => weekTypeFor(new Date()))
  const [lessons, setLessons] = useState<Lesson[]>(demoLessons)
  const [isEditorOpen, setEditorOpen] = useState(false)
  const [calendarOpen, setCalendarOpen] = useState(false)
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null)
  const [newSlot, setNewSlot] = useState<{ day: number, time: string } | null>(null)
  const [notice, setNotice] = useState('')
  const [name, setName] = useState('Alex')
  const [serverState, setServerState] = useState<'loading' | 'ready' | 'demo'>('loading')
  const [notifications, setNotifications] = useState<AppNotification[]>(demoNotifications)
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const [profileOpen, setProfileOpen] = useState(false)
  const [roleEnabled, setRoleEnabled] = useState({ student: true, teacher: true })
  const [catalogOpen, setCatalogOpen] = useState(false)
  const [groupSettingsOpen, setGroupSettingsOpen] = useState(false)

  useEffect(() => {
    const timer = window.setInterval(() => {
      const current = new Date()
      setNow((previous) => {
        if (weekdayIndex(previous) !== weekdayIndex(current)) { setWeek(weekTypeFor(current)); setActiveDay(weekdayIndex(current)) }
        return current
      })
    }, 60_000)
    return () => window.clearInterval(timer)
  }, [])

  useEffect(() => {
    const telegram = initializeTelegram(); setName(telegram.name)
    if (!telegram.initData) { setServerState('demo'); return }
    loadAccount().then(({ profile, lessons: savedLessons, notifications: savedNotifications }) => { setName(profile.displayName || telegram.name); setRole(profile.role); setRoleEnabled({ student: profile.studentEnabled, teacher: profile.teacherEnabled }); setLessons(savedLessons); setNotifications(savedNotifications); setServerState('ready') }).catch(() => { setServerState('demo'); setNotice('Nu s-a putut sincroniza acum. Afișăm exemplul local.') })
  }, [])
  const displayedLessons = useMemo(() => lessons.filter((item) => item.role === role && item.weekday === activeDay && lessonMatchesWeek(item, week)), [activeDay, lessons, role, week])
  const nextLesson = useMemo(() => {
    const nowMinutes = now.getHours() * 60 + now.getMinutes()
    const current = lessons.filter((item) => item.role === role && lessonMatchesWeek(item, week)).map((item) => ({ item, distance: (item.weekday - todayIndex + 7) % 7 }))
      .filter(({ item, distance }) => distance > 0 || (distance === 0 && Number(item.startTime.slice(0, 2)) * 60 + Number(item.startTime.slice(3)) > nowMinutes))
      .sort((a, b) => a.distance - b.distance || a.item.startTime.localeCompare(b.item.startTime))[0]
    return current?.item ?? null
  }, [lessons, now, role, todayIndex, week])
  const saveLesson = async (lesson: Lesson) => { try { const saved = serverState === 'ready' ? await saveLessonRemote(lesson, role) : lesson; setLessons((items) => [...items, saved]); setEditorOpen(false); setNotice(serverState === 'ready' ? 'Ora a fost salvată și se va sincroniza cu botul.' : 'Ora a fost adăugată local. Deschide din Telegram pentru sincronizare.'); } catch { setNotice('Ora nu a putut fi salvată. Încearcă din nou.'); } }
  const saveEditedLesson = async (lesson: Lesson) => { try { const saved = serverState === 'ready' ? await updateLessonRemote(lesson, role) : lesson; setLessons((items) => items.map((item) => item.id === lesson.id ? saved : item)); setEditorOpen(false); setEditingLesson(null); setNotice('Ora a fost modificată.'); } catch { setNotice('Modificarea nu a putut fi salvată.'); } }
  const removeLesson = async (lesson: Lesson) => { if (!window.confirm(`Ștergi „${lesson.title}”?`)) return; try { if (serverState === 'ready') await deleteLessonRemote(lesson.id); setLessons((items) => items.filter((item) => item.id !== lesson.id)); setEditorOpen(false); setEditingLesson(null); setNotice('Ora a fost ștearsă.'); } catch { setNotice('Ora nu a putut fi ștearsă.'); } }
  const openNewLesson = (day = activeDay, time = '08:00') => { setEditingLesson(null); setNewSlot({ day, time }); setEditorOpen(true) }
  const chooseRole = async (next: Role) => { if (next === role) return; if (!roleEnabled[next]) { setNotice(`Modul ${roleLabels[next]} este dezactivat. Activează-l din Profil.`); return } const previous = role; setRole(next); try { if (serverState === 'ready') await updateRole(next) } catch { setRole(previous); setNotice('Rolul nu a putut fi actualizat.'); } }
  const switchRole = () => chooseRole(role === 'student' ? 'teacher' : 'student')
  const toggleRoleEnabled = async (kind: Role) => { const next = !roleEnabled[kind]; setRoleEnabled((value) => ({ ...value, [kind]: next })); try { if (serverState === 'ready') await updateProfileState(kind === 'student' ? { studentEnabled: next } : { teacherEnabled: next }) } catch { setRoleEnabled((value) => ({ ...value, [kind]: !next })); setNotice('Starea nu a putut fi actualizată.') } }
  const currentDate = now.toLocaleDateString('ro-RO', { day: 'numeric', month: 'long' })
  const dateForDay = (dayIndex: number) => { const value = new Date(now); value.setDate(now.getDate() + dayIndex - todayIndex); return value }
  const unreadCount = notifications.filter((item) => !item.readAt).length
  const openNotifications = async () => { setNotificationsOpen(true); if (serverState === 'ready') { try { await markNotificationsRead(); setNotifications((items) => items.map((item) => ({ ...item, readAt: item.readAt ?? new Date().toISOString() }))) } catch { setNotice('Notificările nu au putut fi marcate ca citite.') } } }

  return <main className="app-shell">
    <header className="topbar">
      <div><p className="eyebrow">ORAR UNIVER</p><h1>Bună, {name} <span aria-hidden="true">👋</span></h1></div>
      <button className="avatar" onClick={() => setProfileOpen(true)} aria-label="Deschide profilul">{name.slice(0, 1).toUpperCase()}</button>
    </header>

    <section className="overview" aria-label="Săptămâna curentă">
      <div><span className={`week-badge ${week}`}>{week === 'even' ? 'Săptămână pară' : 'Săptămână impară'}</span><h2>Programul tău,<br />fără griji.</h2><p>Calculat automat pentru data curentă, de la referința 7–13 septembrie 2026.</p></div>
      <div className="next-class" aria-label="Următoarea oră">{nextLesson ? <><span>URMĂTOAREA ORĂ</span><b>{nextLesson.startTime}</b><small>{nextLesson.title}</small><em>{weekdayNames[nextLesson.weekday]}</em></> : <><span>URMĂTOAREA ORĂ</span><b>—</b><small>Nu ai ore planificate</small></>}</div>
    </section>

    <section className="role-card" aria-label="Rol activ">
      <div><span className="role-icon">{role === 'student' ? '🎓' : '🧑‍🏫'}</span><div><strong>{roleLabels[role]}</strong><small>{role === 'student' ? 'Vezi orele grupei tale' : 'Gestionează orele predate'}</small></div></div>
      <div className="role-switch" role="group" aria-label="Alege rolul"><button className={role === 'student' ? 'selected' : ''} onClick={() => chooseRole('student')}>Student</button><button className={role === 'teacher' ? 'selected' : ''} onClick={() => chooseRole('teacher')}>Profesor</button></div>
    </section>

    <nav className="day-tabs" aria-label="Alege ziua">
      {weekdayNames.slice(0, 5).map((day, index) => <button key={day} className={activeDay === index ? 'active' : ''} onClick={() => setActiveDay(index)}><span>{day.slice(0, 2)}</span><b>{dateForDay(index).getDate()}</b></button>)}
    </nav>

    <section className="schedule" aria-labelledby="schedule-heading">
      <div className="section-heading"><div><p>{weekdayNames[activeDay]}, {activeDay === todayIndex ? currentDate : dateForDay(activeDay).toLocaleDateString('ro-RO', { day: 'numeric', month: 'long' })}</p><h2 id="schedule-heading">Orele tale</h2></div><button className="add-button" onClick={() => openNewLesson()} aria-label="Adaugă o oră">+</button></div>
      {serverState === 'loading' ? <p className="sync" role="status">Se conectează la orarul tău…</p> : notice && <p className="success" role="status">✓ {notice}</p>}
      {displayedLessons.length ? <div className="timeline">{displayedLessons.map((lesson) => <LessonCard key={lesson.id} lesson={lesson} role={role} onEdit={() => { setEditingLesson(lesson); setEditorOpen(true) }} />)}</div> : <div className="empty free-day"><span>☀️</span><h3>Ești liber azi</h3><p>Nu ai nicio pereche în această zi. Bucură-te de timp liber!</p><button onClick={() => openNewLesson()}>Adaugă o activitate</button></div>}
    </section>

    <section className="reminder"><span>🔔</span><div><strong>Notificări active</strong><p>Îți amintim cu 15 minute înainte de fiecare oră.</p></div><button onClick={openNotifications}>Vezi {unreadCount ? `(${unreadCount})` : ''}</button></section>
    <footer aria-label="Navigare principală"><button className="nav-item active" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Acasă"><span>⌂</span><small>Acasă</small></button><button className="nav-item" onClick={() => setCalendarOpen(true)}><span>▤</span><small>Orar</small></button><button className="nav-add" onClick={() => openNewLesson()} aria-label="Adaugă oră">＋</button><button className="nav-item footer-notifications" onClick={openNotifications}><BellIcon /><small>Notificări</small>{unreadCount ? <i>{unreadCount}</i> : null}</button>{role === 'teacher' && <button className="nav-item" onClick={() => setCatalogOpen(true)}><span>▦</span><small>Evidență</small></button>}<button className="nav-item" onClick={() => setProfileOpen(true)}><span>◌</span><small>Profil</small></button></footer>
    {isEditorOpen && <LessonEditor role={role} existing={editingLesson} slot={newSlot} onClose={() => { setEditorOpen(false); setEditingLesson(null) }} onSave={editingLesson ? saveEditedLesson : saveLesson} onDelete={editingLesson ? () => removeLesson(editingLesson) : undefined} />}
    {calendarOpen && <CalendarPanel lessons={lessons} role={role} week={week} onClose={() => setCalendarOpen(false)} onAdd={openNewLesson} onEdit={(lesson) => { setEditingLesson(lesson); setCalendarOpen(false); setEditorOpen(true) }} />}
    {notificationsOpen && <NotificationPanel items={notifications} onClose={() => setNotificationsOpen(false)} />}
    {profileOpen && <ProfilePanel name={name} role={role} week={week} enabled={roleEnabled} onClose={() => setProfileOpen(false)} onSwitchRole={switchRole} onToggle={toggleRoleEnabled} onOpenGroupSettings={() => { setProfileOpen(false); setGroupSettingsOpen(true) }} />}
    {groupSettingsOpen && <TeacherCatalog mode="settings" onClose={() => setGroupSettingsOpen(false)} />}
    {catalogOpen && <TeacherCatalog mode="records" onClose={() => setCatalogOpen(false)} />}
  </main>
}

function LessonCard({ lesson, role, onEdit }: { lesson: Lesson, role: Role, onEdit(): void }) { const tone = lesson.weekType === 'odd' ? 'violet' : lesson.weekType === 'even' ? 'blue' : 'teal'; return <article className={`lesson ${tone}`}><time>{lesson.startTime}<small>{lesson.endTime}</small></time><div className="lesson-info"><span>{lesson.weekType === 'both' ? 'În fiecare săptămână' : lesson.weekType === 'even' ? 'Doar săptămână pară' : 'Doar săptămână impară'}</span><h3>{lesson.title}</h3><p>{role === 'teacher' ? lesson.group : lesson.teacher} · Sala {lesson.room}</p></div><button onClick={onEdit} aria-label={`Editează ${lesson.title}`}>•••</button></article> }

function LessonEditor({ role, existing, slot, onClose, onSave, onDelete }: { role: Role, existing: Lesson | null, slot: { day: number, time: string } | null, onClose(): void, onSave(lesson: Lesson): void, onDelete?(): void }) {
  const [title, setTitle] = useState(existing?.title ?? ''); const [group, setGroup] = useState(existing?.group ?? ''); const [room, setRoom] = useState(existing?.room === '—' ? '' : existing?.room ?? ''); const [day, setDay] = useState(existing?.weekday ?? slot?.day ?? 0); const [week, setWeek] = useState<Lesson['weekType']>(existing?.weekType ?? 'both'); const [time, setTime] = useState(existing?.startTime ?? slot?.time ?? '08:00')
  const submit = (event: React.FormEvent) => { event.preventDefault(); if (!title.trim() || !group.trim()) return; onSave({ id: existing?.id ?? crypto.randomUUID(), role: existing?.role ?? role, title, group, teacher: existing?.teacher, weekday: day, startTime: time, endTime: existing?.endTime ?? '09:30', room: room.trim() || '—', weekType: week, reminderMinutes: existing?.reminderMinutes ?? 15 }) }
  return <div className="modal-backdrop" role="presentation"><form className="editor" onSubmit={submit}><div className="modal-heading"><div><p>ORAR MANUAL</p><h2>{existing ? 'Editează ora' : 'Adaugă o oră'}</h2></div><button type="button" onClick={onClose} aria-label="Închide">×</button></div><label>Disciplina<input required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="ex. Algoritmi" /></label><div className="form-row"><label>Grupa<input required value={group} onChange={(e) => setGroup(e.target.value)} placeholder="ex. FAF-241" /></label><label>Sala<input value={room} onChange={(e) => setRoom(e.target.value)} placeholder="ex. 213/4" /></label></div><div className="form-row"><label>Ziua<select value={day} onChange={(e) => setDay(Number(e.target.value))}>{weekdayNames.slice(0, 6).map((x, i) => <option key={x} value={i}>{x}</option>)}</select></label><label>Începe la<input type="time" value={time} onChange={(e) => setTime(e.target.value)} /></label></div><label>Săptămână<select value={week} onChange={(e) => setWeek(e.target.value as Lesson['weekType'])}><option value="both">În fiecare săptămână</option><option value="even">Pară</option><option value="odd">Impară</option></select></label><div className="editor-actions">{onDelete && <button className="delete-button" type="button" onClick={onDelete}>Șterge</button>}<button className="primary" type="submit">{existing ? 'Salvează modificările' : 'Salvează ora'}</button></div></form></div>
}

function NotificationPanel({ items, onClose }: { items: AppNotification[], onClose(): void }) {
  return <div className="modal-backdrop" role="presentation"><section className="notification-panel" role="dialog" aria-modal="true" aria-labelledby="notifications-title"><div className="modal-heading"><div><p>CENTRU NOTIFICĂRI</p><h2 id="notifications-title">Totul la zi</h2></div><button type="button" onClick={onClose} aria-label="Închide">×</button></div>{items.length ? <div className="notification-list">{items.map((item) => <article className={`notification-item ${item.kind}`} key={item.id}><span>{item.kind === 'reminder' ? '🔔' : '✓'}</span><div><h3>{item.title}</h3><p>{item.body}</p><time>{new Date(item.createdAt).toLocaleString('ro-RO', { dateStyle: 'medium', timeStyle: 'short' })}</time></div></article>)}</div> : <div className="empty"><span>🔕</span><h3>Încă nu ai notificări</h3><p>Memento-urile și mesajele sistemului vor apărea aici.</p></div>}</section></div>
}

const timeSlots = ['08:00', '09:45', '11:30', '13:30', '15:15', '17:00', '18:45']
function CalendarPanel({ lessons, role, week, onClose, onAdd, onEdit }: { lessons: Lesson[], role: Role, week: WeekType, onClose(): void, onAdd(day: number, time: string): void, onEdit(lesson: Lesson): void }) {
  return <div className="modal-backdrop calendar-backdrop" role="presentation"><section className="calendar-panel" role="dialog" aria-modal="true" aria-labelledby="calendar-title"><div className="modal-heading"><div><p>ORAR {role === 'teacher' ? 'PROFESOR' : 'STUDENT'} · SĂPTĂMÂNA {week === 'even' ? 'PARĂ' : 'IMPARĂ'}</p><h2 id="calendar-title">Calendarul orelor</h2></div><button type="button" onClick={onClose} aria-label="Închide">×</button></div><p className="calendar-hint">Acesta este orarul de {role === 'teacher' ? 'Profesor' : 'Student'}. Adaugi și editezi doar orele acestui rol.</p><div className="calendar-grid"><div className="calendar-head time-head">Ora</div>{weekdayNames.slice(0, 5).map((day) => <div className="calendar-head" key={day}>{day.slice(0, 2)}</div>)}{timeSlots.flatMap((time) => [<div className="time-label" key={`${time}-label`}>{time}</div>, ...weekdayNames.slice(0, 5).map((_, day) => { const item = lessons.find((lesson) => lesson.role === role && lesson.weekday === day && lesson.startTime === time && lessonMatchesWeek(lesson, week)); return <button className={`calendar-cell ${item ? 'occupied' : ''}`} key={`${day}-${time}`} onClick={() => item ? onEdit(item) : onAdd(day, time)}>{item ? <><b>{item.title}</b><small>{item.room}</small><em>{item.weekType === 'both' ? 'ambele' : item.weekType === 'even' ? 'pară' : 'impară'}</em></> : <span>+</span>}</button> })])}</div></section></div>
}

function ProfilePanel({ name, role, week, enabled, onClose, onSwitchRole, onToggle, onOpenGroupSettings }: { name: string, role: Role, week: WeekType, enabled: Record<Role, boolean>, onClose(): void, onSwitchRole(): void, onToggle(role: Role): void, onOpenGroupSettings(): void }) {
  return <div className="modal-backdrop" role="presentation"><section className="notification-panel profile-panel" role="dialog" aria-modal="true" aria-labelledby="profile-title"><div className="modal-heading"><div><p>CONTUL MEU · TELEGRAM</p><h2 id="profile-title">Profil UTM</h2></div><button type="button" onClick={onClose} aria-label="Închide">×</button></div><div className="profile-hero"><span>{name.slice(0, 1).toUpperCase()}</span><div><h3>{name}</h3><p>Conectat automat prin Telegram</p></div></div><div className="profile-setting"><div><strong>Rol activ</strong><p>{roleLabels[role]}</p></div><button onClick={onSwitchRole}>Schimbă rolul</button></div><div className="profile-setting"><div><strong>Mod Student</strong><p>{enabled.student ? 'Activ — vezi orele tale' : 'Dezactivat'}</p></div><button className={`status-toggle ${enabled.student ? 'on' : ''}`} onClick={() => onToggle('student')} aria-pressed={enabled.student}><i /></button></div><div className="profile-setting"><div><strong>Mod Profesor</strong><p>{enabled.teacher ? 'Activ — gestionezi orele' : 'Dezactivat'}</p></div><button className={`status-toggle ${enabled.teacher ? 'on' : ''}`} onClick={() => onToggle('teacher')} aria-pressed={enabled.teacher}><i /></button></div>{role === 'teacher' && <button className="profile-setting group-settings-link" onClick={onOpenGroupSettings}><span className="setting-icon" aria-hidden="true">⚙</span><div><strong>Setări grupe</strong><p>Grupe, studenți, prezență și note</p></div><span aria-hidden="true">›</span></button>}<div className="profile-setting"><div><strong>Paritatea săptămânii</strong><p>Calcul automat: {week === 'even' ? 'pară' : 'impară'}</p></div><span className="auto-dot">AUTO</span></div><p className="profile-note">Profilul este al contului Telegram cu care ai deschis Mini App-ul. Când redeschizi aplicația, sesiunea se validează automat pe server, iar datele tale rămân separate de ale altor utilizatori.</p></section></div>
}

function BellIcon() { return <svg className="bell-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" /></svg> }

function TeacherCatalog({ mode, onClose }: { mode: 'settings' | 'records', onClose(): void }) {
  const [groups, setGroups] = useState<TeacherGroup[]>([]); const [selected, setSelected] = useState(''); const [students, setStudents] = useState<TeacherStudent[]>([]); const [tab, setTab] = useState<'students'|'attendance'|'grades'>('students'); const [message, setMessage] = useState(''); const [showStudentForm, setShowStudentForm] = useState(false); const [showGroupForm, setShowGroupForm] = useState(false); const [firstName, setFirstName] = useState(''); const [lastName, setLastName] = useState(''); const [groupName, setGroupName] = useState(''); const [subject, setSubject] = useState('');
  const messageFrom = (error: unknown, fallback: string) => {
    const detail = error instanceof Error ? error.message : ''
    if (detail.includes('Telegram authentication failed')) return 'Sesiunea Telegram a expirat. Închide și redeschide Mini App-ul din bot.'
    if (detail.includes('PostgreSQL')) return 'Catalogul pornește sau baza de date nu este disponibilă. Încearcă din nou în câteva momente.'
    return detail || fallback
  }
  const refreshGroups = () => loadTeacherGroups().then((items) => { setGroups(items); if (!selected && items[0]) setSelected(items[0].id); setMessage('') }).catch((error) => setMessage(messageFrom(error, 'Catalogul nu este disponibil momentan. Încearcă din nou în câteva momente.')))
  useEffect(() => { void refreshGroups() }, []); useEffect(() => { if (selected) loadTeacherStudents(selected).then(setStudents).catch(() => setMessage('Nu s-au putut încărca studenții.')) }, [selected])
  const addGroup = async (event: React.FormEvent) => { event.preventDefault(); if (!groupName.trim()) return; try { const group = await createTeacherGroup(groupName, subject); setGroups((items) => [...items, group]); setSelected(group.id); setGroupName(''); setSubject(''); setShowGroupForm(false); setMessage(`Grupa ${group.name} a fost salvată.`) } catch (error) { setMessage(messageFrom(error, 'Grupa nu a fost salvată.')) } }
  const addStudent = async (event: React.FormEvent) => { event.preventDefault(); if (!firstName.trim() || !lastName.trim() || !selected) return; try { const student = await createTeacherStudent(selected, firstName, lastName); setStudents((items) => [...items, student]); setFirstName(''); setLastName(''); setShowStudentForm(false); setMessage('Studentul a fost adăugat.') } catch (error) { setMessage(messageFrom(error, 'Studentul nu a fost salvat.')) } }
  const attendance = async (student: TeacherStudent, status: 'present'|'absent'|'late') => { if (!selected) return; try { await saveAttendance(selected, students.map((item) => ({ studentId: item.id, status: item.id === student.id ? status : 'present' }))); setMessage('Prezența a fost salvată.') } catch (error) { setMessage(messageFrom(error, 'Prezența nu a fost salvată.')) } }
  const grade = async (student: TeacherStudent) => { const value = window.prompt(`Nota de laborator pentru ${student.last_name} ${student.first_name} (0–10)`); const score = Number(value); if (!Number.isFinite(score) || score < 0 || score > 10) return; try { await saveLabGrade(student.id, 'Laborator', score); setMessage(`Nota ${score} a fost salvată.`) } catch (error) { setMessage(messageFrom(error, 'Nota nu a fost salvată.')) } }
  const isSettings = mode === 'settings'
  return <div className="modal-backdrop"><section className="catalog-panel"><div className="modal-heading"><div><p>{isSettings ? 'PROFIL PROFESOR · SETĂRI' : 'CATALOG PROFESOR · EVIDENȚĂ'}</p><h2>{isSettings ? 'Setări grupe' : 'Prezență și note'}</h2></div><button onClick={onClose} aria-label="Închide">×</button></div><p className="catalog-subtitle">{isSettings ? 'Creezi grupe și adaugi studenți în grupele existente.' : 'Selectezi grupa și completezi prezența sau notele de laborator.'}</p><div className="catalog-toolbar"><select value={selected} onChange={(e) => setSelected(e.target.value)}><option value="">Alege grupa</option>{groups.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select>{isSettings && <button onClick={() => setShowGroupForm(true)}>＋ Creează grupă</button>}</div>{isSettings && groups.length > 0 && <section className="existing-groups" aria-label="Grupe existente"><strong>Grupele mele</strong><div>{groups.map((item) => <button className={item.id === selected ? 'selected' : ''} key={item.id} onClick={() => setSelected(item.id)}><span aria-hidden="true">👥</span>{item.name}<small>{item.student_count} stud.</small></button>)}</div></section>}{isSettings && showGroupForm && <form className="catalog-form" onSubmit={addGroup}><strong>Grupă nouă</strong><input autoFocus value={groupName} onChange={(e) => setGroupName(e.target.value)} placeholder="ex. SI-265 PC" /><input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Disciplina (opțional)" /><div><button type="button" onClick={() => setShowGroupForm(false)}>Anulează</button><button type="submit">Salvează grupa</button></div></form>}{!isSettings && <nav className="catalog-tabs"><button className={tab==='attendance'?'active':''} onClick={() => setTab('attendance')}>Prezență</button><button className={tab==='grades'?'active':''} onClick={() => setTab('grades')}>Note</button></nav>}{message && <p className="catalog-message">{message}</p>}<div className="student-list">{isSettings && <>{!showStudentForm && <button className="add-student" disabled={!selected} onClick={() => setShowStudentForm(true)}>＋ Adaugă student</button>}{showStudentForm && <form className="catalog-form" onSubmit={addStudent}><strong>Student nou</strong><div className="form-row"><input autoFocus value={lastName} onChange={(e) => setLastName(e.target.value)} placeholder="Nume" /><input value={firstName} onChange={(e) => setFirstName(e.target.value)} placeholder="Prenume" /></div><div><button type="button" onClick={() => setShowStudentForm(false)}>Anulează</button><button type="submit">Adaugă studentul</button></div></form>}</>}{students.length ? students.map((student, index) => <article key={student.id}><b>{index + 1}</b><span>{student.last_name} {student.first_name}</span>{!isSettings && tab==='attendance' && <div><button onClick={() => attendance(student,'present')}>P</button><button onClick={() => attendance(student,'absent')}>A</button><button onClick={() => attendance(student,'late')}>Î</button></div>}{!isSettings && tab==='grades' && <button onClick={() => grade(student)}>Pune notă</button>}</article>) : <div className="empty-catalog"><span>👥</span><strong>{selected ? 'Lista este goală' : 'Alege o grupă'}</strong><p>{selected ? (isSettings ? 'Adaugă primul student pentru a începe evidența.' : 'Adaugă studenți din Profil → Setări grupe.') : 'Creează sau selectează o grupă pentru a vedea catalogul.'}</p></div>}</div></section></div>
}
