import type { AppNotification, Lesson, Role } from './types'

const apiBase = import.meta.env.VITE_API_URL ?? ''
const initData = () => window.Telegram?.WebApp?.initData ?? ''

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${apiBase}${path}`, { ...options, headers: { 'Content-Type': 'application/json', 'X-Telegram-Init-Data': initData(), ...options.headers } })
  if (!response.ok) { const body = await response.json().catch(() => null); throw new Error(body?.error ?? 'Cererea nu a reușit.') }
  return response.status === 204 ? undefined as T : response.json() as Promise<T>
}

type ApiLesson = { id: number; role: Role; title: string; groupName: string | null; teacherName: string | null; room: string | null; weekday: number; startTime: string; endTime: string; weekKind: 'odd' | 'even' | 'every'; reminderMinutes: number }
const fromApi = (item: ApiLesson): Lesson => ({ id: String(item.id), role: item.role, title: item.title, group: item.groupName ?? '', teacher: item.teacherName ?? undefined, room: item.room ?? '—', weekday: item.weekday - 1, startTime: item.startTime, endTime: item.endTime, weekType: item.weekKind === 'every' ? 'both' : item.weekKind, reminderMinutes: item.reminderMinutes })

export type AccountProfile = { displayName: string, role: Role, studentEnabled: boolean, teacherEnabled: boolean }
export async function loadAccount() { const [me, items, notifications] = await Promise.all([request<{ profile: AccountProfile }>('/api/me'), request<ApiLesson[]>('/api/lessons'), request<AppNotification[]>('/api/notifications')]); return { profile: me.profile, lessons: items.map(fromApi), notifications } }
export async function saveLessonRemote(lesson: Lesson, role: Role) { const created = await request<ApiLesson>('/api/lessons', { method: 'POST', body: JSON.stringify({ role, title: lesson.title, groupName: lesson.group || null, teacherName: lesson.teacher || null, room: lesson.room === '—' ? null : lesson.room, weekday: lesson.weekday + 1, startTime: lesson.startTime, endTime: lesson.endTime, weekKind: lesson.weekType === 'both' ? 'every' : lesson.weekType, reminderMinutes: lesson.reminderMinutes, notificationsEnabled: true }) }); return fromApi(created) }
export function updateRole(role: Role) { return request('/api/me', { method: 'PATCH', body: JSON.stringify({ role }) }) }
export function updateProfileState(change: Partial<Pick<AccountProfile, 'studentEnabled' | 'teacherEnabled'>>) { return request<AccountProfile>('/api/me', { method: 'PATCH', body: JSON.stringify(change) }) }
export type TeacherGroup = { id: string, name: string, subject?: string, student_count: number }
export type TeacherStudent = { id: string, first_name: string, last_name: string }
export const loadTeacherGroups = () => request<TeacherGroup[]>('/api/teacher/groups')
export const createTeacherGroup = (name: string, subject: string) => request<TeacherGroup>('/api/teacher/groups', { method: 'POST', body: JSON.stringify({ name, subject }) })
export const loadTeacherStudents = (groupId: string) => request<TeacherStudent[]>(`/api/teacher/groups/${groupId}/students`)
export const createTeacherStudent = (groupId: string, firstName: string, lastName: string) => request<TeacherStudent>(`/api/teacher/groups/${groupId}/students`, { method: 'POST', body: JSON.stringify({ firstName, lastName }) })
export const saveAttendance = (groupId: string, entries: Array<{ studentId: string, status: 'present' | 'absent' | 'late' }>) => request<void>(`/api/teacher/groups/${groupId}/attendance`, { method: 'POST', body: JSON.stringify({ date: new Date().toISOString().slice(0, 10), entries }) })
export const saveLabGrade = (studentId: string, laboratory: string, grade: number) => request(`/api/teacher/students/${studentId}/grades`, { method: 'POST', body: JSON.stringify({ laboratory, grade, presentedOn: new Date().toISOString().slice(0, 10) }) })
export function markNotificationsRead() { return request<void>('/api/notifications/read', { method: 'PATCH' }) }
export async function updateLessonRemote(lesson: Lesson, role: Role) { const saved = await request<ApiLesson>(`/api/lessons/${lesson.id}`, { method: 'PUT', body: JSON.stringify({ role, title: lesson.title, groupName: lesson.group || null, teacherName: lesson.teacher || null, room: lesson.room === '—' ? null : lesson.room, weekday: lesson.weekday + 1, startTime: lesson.startTime, endTime: lesson.endTime, weekKind: lesson.weekType === 'both' ? 'every' : lesson.weekType, reminderMinutes: lesson.reminderMinutes, notificationsEnabled: true }) }); return fromApi(saved) }
export function deleteLessonRemote(id: string) { return request<void>(`/api/lessons/${id}`, { method: 'DELETE' }) }
