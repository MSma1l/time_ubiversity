declare global { interface Window { Telegram?: { WebApp?: { ready(): void; expand(): void; colorScheme?: 'light' | 'dark'; initData?: string; initDataUnsafe?: { user?: { first_name?: string } } } } } }

export function initializeTelegram() {
  const app = window.Telegram?.WebApp
  app?.ready()
  app?.expand()
  return { name: app?.initDataUnsafe?.user?.first_name ?? 'Alex', initData: app?.initData ?? '' }
}
