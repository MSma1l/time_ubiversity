import type { Lesson, WeekType } from './types'

export const demoLessons: Lesson[] = [
  { id: '1', role: 'student', title: 'Programare orientată pe obiecte', group: 'FAF-241', teacher: 'D. Rusu', room: '213/4', weekday: 1, startTime: '08:00', endTime: '09:30', weekType: 'both', reminderMinutes: 20 },
  { id: '2', role: 'student', title: 'Baze de date', group: 'FAF-241', teacher: 'S. Ceban', room: '305/4', weekday: 1, startTime: '09:45', endTime: '11:15', weekType: 'odd', reminderMinutes: 15 },
  { id: '3', role: 'student', title: 'Inteligență artificială', group: 'FAF-241', teacher: 'A. Popa', room: '214/4', weekday: 1, startTime: '11:30', endTime: '13:00', weekType: 'even', reminderMinutes: 15 },
  { id: '4', role: 'teacher', title: 'Rețele de calculatoare', group: 'SI-265 PC', teacher: 'D. Turcan', room: '401/4', weekday: 2, startTime: '11:30', endTime: '13:00', weekType: 'both', reminderMinutes: 15 },
  { id: '5', role: 'teacher', title: 'Ingineria programării', group: 'SI-265 PC', teacher: 'D. Turcan', room: '108/4', weekday: 3, startTime: '13:15', endTime: '14:45', weekType: 'both', reminderMinutes: 15 },
]

export const weekdayNames = ['Luni', 'Marți', 'Miercuri', 'Joi', 'Vineri', 'Sâmbătă', 'Duminică']

// Academic calendar baseline supplied by the user: 7–13 Sep 2026 is an even week.
export function weekTypeFor(date: Date): WeekType {
  const baseline = new Date(2026, 8, 7)
  baseline.setHours(0, 0, 0, 0)
  const target = new Date(date)
  target.setHours(0, 0, 0, 0)
  const weeks = Math.floor((target.getTime() - baseline.getTime()) / 604_800_000)
  return Math.abs(weeks) % 2 === 0 ? 'even' : 'odd'
}

export function lessonMatchesWeek(lesson: Lesson, week: WeekType) {
  return lesson.weekType === 'both' || lesson.weekType === week
}
