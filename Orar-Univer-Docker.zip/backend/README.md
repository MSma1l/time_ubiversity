# Orar Univer API

API-ul rulează separat de Mini App și păstrează orarul în SQLite. În producție, setează valorile din `.env.example`, montează un volum persistent la `/data` și expune aplicația doar printr-un proxy HTTPS.

```sh
cd backend
cp .env.example .env
npm install
npm run dev
```

Mini App-ul trimite `Telegram.WebApp.initData` în headerul `X-Telegram-Init-Data`. Serverul îl verifică înaintea fiecărei operații; `X-Dev-Telegram-Id` este acceptat doar cu `ALLOW_DEV_AUTH=true` pentru dezvoltare locală.

După ce domeniul este public și HTTPS, setează webhook-ul o singură dată:

```sh
curl -X POST "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/setWebhook" \
  -d "url=https://api.exemplu.md/telegram/webhook"
```

Referința de paritate este configurată explicit: intervalul 7–13 septembrie 2026 este **par** (`even`). Memento-urile sunt evaluate la fiecare minut în fusul `Europe/Chisinau` și sunt înregistrate pentru a evita duplicarea.
