import "dotenv/config";
import cors from "cors";
import express, { type NextFunction, type Request, type Response } from "express";
import helmet from "helmet";
import cron from "node-cron";
import { z, ZodError } from "zod";
import { openDatabase, type Lesson } from "./db.js";
import { appliesInWeek, isoDateInChisinau, universityWeekKind, universityWeekNumber } from "./schedule.js";
import { telegramApi, telegramApiResponse, validateInitData, type TelegramUser } from "./telegram.js";
import { academicDatabase, ensureAcademicSchema } from "./academic.js";

const config = {
  port: Number(process.env.PORT ?? 3001), token: process.env.TELEGRAM_BOT_TOKEN ?? "",
  miniAppUrl: process.env.MINI_APP_URL ?? "", databasePath: process.env.DATABASE_PATH ?? "./data/orar.sqlite",
  allowDevAuth: process.env.ALLOW_DEV_AUTH === "true",
  origins: (process.env.ALLOWED_ORIGINS ?? "").split(",").filter(Boolean), polling: process.env.TELEGRAM_POLLING === "true"
};
const db = openDatabase(config.databasePath);
// The API can start before the PostgreSQL container becomes ready.  Catalog
// requests retry the schema check, so a short database startup does not leave
// the catalog permanently unusable until the API is restarted.
void ensureAcademicSchema().catch(() => console.warn("PostgreSQL catalog is not ready yet"));
const app = express();
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({ origin: config.origins.length ? config.origins : false }));
app.use(express.json({ limit: "64kb" }));

type AuthRequest = Request & { telegramUser: TelegramUser };
function auth(req: Request, res: Response, next: NextFunction) {
  const initData = req.header("x-telegram-init-data") ?? "";
  let user = validateInitData(initData, config.token);
  if (!user && config.allowDevAuth && req.header("x-dev-telegram-id")) {
    const id = Number(req.header("x-dev-telegram-id"));
    if (Number.isSafeInteger(id)) user = { id, first_name: "Developer" };
  }
  if (!user) return res.status(401).json({ error: "Telegram authentication failed. Reopen the Mini App." });
  (req as AuthRequest).telegramUser = user;
  db.prepare("INSERT INTO profiles (telegram_id, display_name) VALUES (?, ?) ON CONFLICT(telegram_id) DO UPDATE SET display_name=excluded.display_name")
    .run(user.id, [user.first_name, user.last_name].filter(Boolean).join(" "));
  next();
}

const lessonSchema = z.object({
  role: z.enum(["student", "teacher"]), title: z.string().trim().min(1).max(120),
  groupName: z.string().trim().max(80).nullable().optional(), teacherName: z.string().trim().max(100).nullable().optional(),
  room: z.string().trim().max(60).nullable().optional(), weekday: z.number().int().min(1).max(7),
  startTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/), endTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  weekKind: z.enum(["odd", "even", "every"]), reminderMinutes: z.number().int().min(0).max(180), notificationsEnabled: z.boolean()
}).refine((item) => item.endTime > item.startTime, { message: "Ora de final trebuie să fie după ora de început", path: ["endTime"] });

function lessonRows(ownerId: number): Lesson[] {
  const rows = db.prepare("SELECT id, owner_id AS ownerId, role, title, group_name AS groupName, teacher_name AS teacherName, room, weekday, start_time AS startTime, end_time AS endTime, week_kind AS weekKind, reminder_minutes AS reminderMinutes, notifications_enabled AS notificationsEnabled FROM lessons WHERE owner_id=? ORDER BY weekday,start_time")
    .all(ownerId) as Lesson[];
  return rows.map((lesson) => ({ ...lesson, notificationsEnabled: Boolean(lesson.notificationsEnabled) }));
}

function addNotification(ownerId: number, kind: "reminder" | "system", title: string, body: string) {
  db.prepare("INSERT INTO notifications (owner_id, kind, title, body) VALUES (?,?,?,?)").run(ownerId, kind, title, body);
}

app.get("/health", (_req, res) => res.json({ ok: true }));
app.get("/api/me", auth, (req, res) => {
  const user = (req as AuthRequest).telegramUser;
  const profile = db.prepare("SELECT telegram_id AS telegramId, display_name AS displayName, role, timezone, student_enabled AS studentEnabled, teacher_enabled AS teacherEnabled FROM profiles WHERE telegram_id=?").get(user.id);
  res.json({ profile, telegram: { id: user.id, firstName: user.first_name, username: user.username } });
});
app.patch("/api/me", auth, (req, res) => {
  const body = z.object({ role: z.enum(["student", "teacher"]).optional(), studentEnabled: z.boolean().optional(), teacherEnabled: z.boolean().optional() }).refine((value) => Object.keys(value).length > 0).parse(req.body);
  const user = (req as AuthRequest).telegramUser;
  if (body.role) db.prepare("UPDATE profiles SET role=? WHERE telegram_id=?").run(body.role, user.id);
  if (body.studentEnabled !== undefined) db.prepare("UPDATE profiles SET student_enabled=? WHERE telegram_id=?").run(Number(body.studentEnabled), user.id);
  if (body.teacherEnabled !== undefined) db.prepare("UPDATE profiles SET teacher_enabled=? WHERE telegram_id=?").run(Number(body.teacherEnabled), user.id);
  res.json(db.prepare("SELECT telegram_id AS telegramId, display_name AS displayName, role, student_enabled AS studentEnabled, teacher_enabled AS teacherEnabled FROM profiles WHERE telegram_id=?").get(user.id));
});
app.get("/api/week", auth, (req, res) => {
  const requested = typeof req.query.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(req.query.date) ? req.query.date : isoDateInChisinau();
  res.json({ date: requested, number: universityWeekNumber(requested), kind: universityWeekKind(requested), referenceMonday: "2026-09-07", referenceKind: "even" });
});
app.get("/api/lessons", auth, (req, res) => res.json(lessonRows((req as AuthRequest).telegramUser.id)));
const groupSchema = z.object({ name: z.string().trim().min(2).max(80), subject: z.string().trim().max(120).optional() });
const studentSchema = z.object({ firstName: z.string().trim().min(1).max(80), lastName: z.string().trim().min(1).max(80) });
async function postgresOr503(res: Response) {
  const pg = academicDatabase();
  if (!pg) {
    res.status(503).json({ error: "Catalogul Profesor necesită PostgreSQL. Pornește serviciul postgres." });
    return undefined;
  }
  try {
    await ensureAcademicSchema();
    return pg;
  } catch {
    res.status(503).json({ error: "Catalogul Profesor nu se poate conecta încă la PostgreSQL. Așteaptă câteva secunde și reîncearcă." });
    return undefined;
  }
}
app.get("/api/teacher/groups", auth, async (req, res, next) => { try { const pg = await postgresOr503(res); if (!pg) return; const ownerId = (req as AuthRequest).telegramUser.id; const result = await pg.query("SELECT g.*, COUNT(s.id)::int AS student_count FROM academic_groups g LEFT JOIN students s ON s.group_id=g.id WHERE g.owner_id=$1 GROUP BY g.id ORDER BY g.name", [ownerId]); res.json(result.rows); } catch (error) { next(error); } });
app.post("/api/teacher/groups", auth, async (req, res, next) => { try { const pg = await postgresOr503(res); if (!pg) return; const input = groupSchema.parse(req.body); const ownerId = (req as AuthRequest).telegramUser.id; const result = await pg.query("INSERT INTO academic_groups(owner_id,name,subject) VALUES($1,$2,$3) RETURNING *", [ownerId, input.name, input.subject ?? null]); res.status(201).json(result.rows[0]); } catch (error) { next(error); } });
app.get("/api/teacher/groups/:groupId/students", auth, async (req, res, next) => { try { const pg = await postgresOr503(res); if (!pg) return; const ownerId = (req as AuthRequest).telegramUser.id; const valid = await pg.query("SELECT id FROM academic_groups WHERE id=$1 AND owner_id=$2", [req.params.groupId, ownerId]); if (!valid.rowCount) return res.status(404).json({ error: "Grupa nu a fost găsită" }); const result = await pg.query("SELECT * FROM students WHERE group_id=$1 ORDER BY last_name,first_name", [req.params.groupId]); res.json(result.rows); } catch (error) { next(error); } });
app.post("/api/teacher/groups/:groupId/students", auth, async (req, res, next) => { try { const pg = await postgresOr503(res); if (!pg) return; const input = studentSchema.parse(req.body); const ownerId = (req as AuthRequest).telegramUser.id; const group = await pg.query("SELECT id FROM academic_groups WHERE id=$1 AND owner_id=$2", [req.params.groupId, ownerId]); if (!group.rowCount) return res.status(404).json({ error: "Grupa nu a fost găsită" }); const result = await pg.query("INSERT INTO students(group_id,first_name,last_name) VALUES($1,$2,$3) RETURNING *", [req.params.groupId, input.firstName, input.lastName]); res.status(201).json(result.rows[0]); } catch (error) { next(error); } });
app.post("/api/teacher/groups/:groupId/attendance", auth, async (req, res, next) => { try { const pg = await postgresOr503(res); if (!pg) return; const input = z.object({ date: z.string().date(), topic: z.string().trim().max(160).optional(), entries: z.array(z.object({ studentId: z.string().uuid(), status: z.enum(["present", "absent", "late"]) })).max(200) }).parse(req.body); const ownerId = (req as AuthRequest).telegramUser.id; const group = await pg.query("SELECT id FROM academic_groups WHERE id=$1 AND owner_id=$2", [req.params.groupId, ownerId]); if (!group.rowCount) return res.status(404).json({ error: "Grupa nu a fost găsită" }); const session = await pg.query("INSERT INTO attendance_sessions(group_id,occurred_on,topic) VALUES($1,$2,$3) ON CONFLICT(group_id,occurred_on) DO UPDATE SET topic=EXCLUDED.topic RETURNING id", [req.params.groupId, input.date, input.topic ?? null]); for (const entry of input.entries) await pg.query("INSERT INTO attendance_entries(session_id,student_id,status) VALUES($1,$2,$3) ON CONFLICT(session_id,student_id) DO UPDATE SET status=EXCLUDED.status", [session.rows[0].id, entry.studentId, entry.status]); res.status(204).end(); } catch (error) { next(error); } });
app.post("/api/teacher/students/:studentId/grades", auth, async (req, res, next) => { try { const pg = await postgresOr503(res); if (!pg) return; const input = z.object({ laboratory: z.string().trim().min(1).max(120), grade: z.number().min(0).max(10), presentedOn: z.string().date().optional(), feedback: z.string().trim().max(500).optional() }).parse(req.body); const ownerId = (req as AuthRequest).telegramUser.id; const result = await pg.query("INSERT INTO lab_grades(student_id,laboratory,grade,presented_on,feedback) SELECT s.id,$2,$3,$4,$5 FROM students s JOIN academic_groups g ON g.id=s.group_id WHERE s.id=$1 AND g.owner_id=$6 RETURNING *", [req.params.studentId, input.laboratory, input.grade, input.presentedOn ?? null, input.feedback ?? null, ownerId]); if (!result.rowCount) return res.status(404).json({ error: "Studentul nu a fost găsit" }); res.status(201).json(result.rows[0]); } catch (error) { next(error); } });
app.get("/api/notifications", auth, (req, res) => {
  const ownerId = (req as AuthRequest).telegramUser.id;
  const rows = db.prepare("SELECT id, kind, title, body, read_at AS readAt, created_at AS createdAt FROM notifications WHERE owner_id=? ORDER BY id DESC LIMIT 50").all(ownerId);
  res.json(rows);
});
app.patch("/api/notifications/read", auth, (req, res) => {
  const ownerId = (req as AuthRequest).telegramUser.id;
  db.prepare("UPDATE notifications SET read_at=CURRENT_TIMESTAMP WHERE owner_id=? AND read_at IS NULL").run(ownerId);
  res.status(204).end();
});
app.post("/api/lessons", auth, (req, res) => {
  const input = lessonSchema.parse(req.body); const ownerId = (req as AuthRequest).telegramUser.id;
  const result = db.prepare(`INSERT INTO lessons (owner_id,role,title,group_name,teacher_name,room,weekday,start_time,end_time,week_kind,reminder_minutes,notifications_enabled) VALUES (@ownerId,@role,@title,@groupName,@teacherName,@room,@weekday,@startTime,@endTime,@weekKind,@reminderMinutes,@notificationsEnabled)`)
    .run({ ...input, groupName: input.groupName ?? null, teacherName: input.teacherName ?? null, room: input.room ?? null, ownerId, notificationsEnabled: Number(input.notificationsEnabled) });
  addNotification(ownerId, "system", "Orar actualizat", `Ai adăugat: ${input.title}, ${input.startTime}–${input.endTime}.`);
  res.status(201).json(lessonRows(ownerId).find((lesson) => lesson.id === result.lastInsertRowid));
});
app.put("/api/lessons/:id", auth, (req, res) => {
  const input = lessonSchema.parse(req.body); const ownerId = (req as AuthRequest).telegramUser.id; const id = z.coerce.number().int().positive().parse(req.params.id);
  const result = db.prepare(`UPDATE lessons SET role=@role,title=@title,group_name=@groupName,teacher_name=@teacherName,room=@room,weekday=@weekday,start_time=@startTime,end_time=@endTime,week_kind=@weekKind,reminder_minutes=@reminderMinutes,notifications_enabled=@notificationsEnabled,updated_at=CURRENT_TIMESTAMP WHERE id=@id AND owner_id=@ownerId`)
    .run({ ...input, groupName: input.groupName ?? null, teacherName: input.teacherName ?? null, room: input.room ?? null, id, ownerId, notificationsEnabled: Number(input.notificationsEnabled) });
  if (!result.changes) return res.status(404).json({ error: "Ora nu a fost găsită" });
  res.json(lessonRows(ownerId).find((lesson) => lesson.id === id));
});
app.delete("/api/lessons/:id", auth, (req, res) => {
  const id = z.coerce.number().int().positive().parse(req.params.id); const ownerId = (req as AuthRequest).telegramUser.id;
  const result = db.prepare("DELETE FROM lessons WHERE id=? AND owner_id=?").run(id, ownerId);
  if (!result.changes) return res.status(404).json({ error: "Ora nu a fost găsită" });
  res.status(204).end();
});

async function sendDueReminders() {
  if (!config.token) return;
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Chisinau", weekday: "short", hour: "2-digit", minute: "2-digit", hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const value = (name: string) => parts.find((p) => p.type === name)?.value ?? "";
  const weekday = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(value("weekday")) + 1;
  const today = `${value("year")}-${value("month")}-${value("day")}`; const minutesNow = Number(value("hour")) * 60 + Number(value("minute"));
  for (const lesson of db.prepare("SELECT id, owner_id AS ownerId, role, title, group_name AS groupName, teacher_name AS teacherName, room, weekday, start_time AS startTime, end_time AS endTime, week_kind AS weekKind, reminder_minutes AS reminderMinutes, notifications_enabled AS notificationsEnabled FROM lessons WHERE weekday=? AND notifications_enabled=1").all(weekday) as Lesson[]) {
    const [hour, minute] = lesson.startTime.split(":").map(Number);
    if (!appliesInWeek(lesson.weekKind, today) || hour * 60 + minute - lesson.reminderMinutes !== minutesNow) continue;
    const key = `${today}-${lesson.startTime}`;
    try {
      await telegramApi(config.token, "sendMessage", { chat_id: lesson.ownerId, text: `🔔 În ${lesson.reminderMinutes} min: ${lesson.title}\n${lesson.startTime}–${lesson.endTime}${lesson.room ? ` · Sala ${lesson.room}` : ""}${lesson.groupName ? ` · Grupa ${lesson.groupName}` : ""}`, reply_markup: config.miniAppUrl ? { inline_keyboard: [[{ text: "Deschide orarul", web_app: { url: config.miniAppUrl } }]] } : undefined });
      db.prepare("INSERT INTO delivered_reminders (lesson_id, occurrence_key) VALUES (?,?)").run(lesson.id, key);
      addNotification(lesson.ownerId, "reminder", `În ${lesson.reminderMinutes} minute începe ${lesson.title}`, `${lesson.startTime}–${lesson.endTime}${lesson.room ? ` · Sala ${lesson.room}` : ""}${lesson.groupName ? ` · Grupa ${lesson.groupName}` : ""}`);
    } catch (error) { if (!(error instanceof Error && error.message.includes("SQLITE_CONSTRAINT"))) console.error("Reminder error", error); }
  }
}
cron.schedule("* * * * *", () => { void sendDueReminders(); }, { timezone: "Europe/Chisinau", noOverlap: true });

type TelegramMessage = { text?: string, chat?: { id: number, type?: string }, from?: TelegramUser };
function weekdayForChisinau() { return ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Chisinau", weekday: "short" }).format(new Date())) + 1; }
function formatLesson(lesson: Lesson) { return `• ${lesson.startTime}–${lesson.endTime} — ${lesson.title}${lesson.room ? ` (sala ${lesson.room})` : ""}`; }
async function handleBotMessage(message: TelegramMessage) {
  const chatId = message.chat?.id; const text = message.text?.trim() ?? "";
  if (!chatId || !text.startsWith("/") || !config.token) return;
  const command = text.split(/\s+/)[0].split("@")[0].toLowerCase(); const argument = text.split(/\s+/).slice(1).join(" ").toLowerCase();
  if (message.from) db.prepare("INSERT INTO profiles (telegram_id, display_name) VALUES (?, ?) ON CONFLICT(telegram_id) DO UPDATE SET display_name=excluded.display_name").run(chatId, [message.from.first_name, message.from.last_name].filter(Boolean).join(" "));
  const today = isoDateInChisinau(); const kind = universityWeekKind(today); const todayLessons = lessonRows(chatId).filter((lesson) => lesson.weekday === weekdayForChisinau() && appliesInWeek(lesson.weekKind, today));
  let answer = "";
  if (command === "/start" || command === "/help") answer = "Bun venit la Orar UTM!\n\n/azi — orarul de azi\n/saptamana — orarul săptămânii curente\n/rol student|profesor — schimbă rolul\n/notificari on|off — activează/dezactivează memento-urile\n/status — starea contului";
  else if (command === "/azi") answer = todayLessons.length ? `📚 Orarul de azi (${kind === "even" ? "săptămână pară" : "săptămână impară"}):\n${todayLessons.map(formatLesson).join("\n")}` : "☀️ Ești liber azi — nu ai nicio pereche programată.";
  else if (command === "/saptamana") { const entries = lessonRows(chatId).filter((lesson) => appliesInWeek(lesson.weekKind, today)); answer = entries.length ? `📅 Săptămâna ${kind === "even" ? "pară" : "impară"}:\n${entries.map((lesson) => `${["Lu", "Ma", "Mi", "Jo", "Vi", "Sâ", "Du"][lesson.weekday - 1]} ${formatLesson(lesson)}`).join("\n")}` : "Nu ai ore în această săptămână."; }
  else if (command === "/rol" && (argument === "student" || argument === "profesor")) { const role = argument === "profesor" ? "teacher" : "student"; db.prepare("UPDATE profiles SET role=? WHERE telegram_id=?").run(role, chatId); answer = `Rol activ: ${argument}.`; }
  else if (command === "/notificari" && (argument === "on" || argument === "off")) { db.prepare("UPDATE lessons SET notifications_enabled=? WHERE owner_id=?").run(argument === "on" ? 1 : 0, chatId); answer = argument === "on" ? "🔔 Memento-urile sunt active." : "🔕 Memento-urile sunt oprite."; }
  else if (command === "/status") { const profile = db.prepare("SELECT role FROM profiles WHERE telegram_id=?").get(chatId) as { role?: string } | undefined; answer = `Cont activ · rol: ${profile?.role === "teacher" ? "profesor" : "student"} · săptămână ${kind === "even" ? "pară" : "impară"}.`; }
  else answer = "Nu cunosc această comandă. Trimite /help pentru lista comenzilor.";
  await telegramApi(config.token, "sendMessage", { chat_id: chatId, text: answer, reply_markup: config.miniAppUrl?.startsWith("https://") ? { inline_keyboard: [[{ text: "Deschide Orarul", web_app: { url: config.miniAppUrl } }]] } : undefined });
}
app.post("/telegram/webhook", async (req, res) => { await handleBotMessage(req.body?.message); res.sendStatus(200); });

async function pollTelegram() {
  let offset = 0;
  while (config.polling && config.token) {
    try {
      const updates = await telegramApiResponse<Array<{ update_id: number, message?: TelegramMessage }>>(config.token, "getUpdates", { offset, timeout: 25, allowed_updates: ["message"] });
      for (const update of updates) { offset = update.update_id + 1; if (update.message) await handleBotMessage(update.message); }
    } catch (error) { console.error("Telegram polling error", error); await new Promise((resolve) => setTimeout(resolve, 3_000)); }
  }
}
if (config.polling) void pollTelegram();

app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (error instanceof ZodError) return res.status(400).json({ error: "Date invalide", fields: error.issues.map((issue) => ({ path: issue.path.join("."), message: issue.message })) });
  console.error(error); res.status(500).json({ error: "Eroare internă" });
});

app.listen(config.port, () => console.log(`Orar API listens on ${config.port}`));
