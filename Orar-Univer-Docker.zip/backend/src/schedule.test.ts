import { describe, expect, it } from "vitest";
import { appliesInWeek, universityWeekKind, universityWeekNumber } from "./schedule.js";

describe("university week cycle", () => {
  it("uses 7–13 September 2026 as even", () => {
    expect(universityWeekNumber("2026-09-07")).toBe(1);
    expect(universityWeekKind("2026-09-07")).toBe("even");
    expect(universityWeekKind("2026-09-14")).toBe("odd");
  });
  it("matches every and the matching parity", () => {
    expect(appliesInWeek("every", "2026-09-14")).toBe(true);
    expect(appliesInWeek("odd", "2026-09-14")).toBe(true);
    expect(appliesInWeek("even", "2026-09-14")).toBe(false);
  });
});
