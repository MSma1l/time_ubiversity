import { createHmac, timingSafeEqual } from "node:crypto";

export type TelegramUser = { id: number; first_name: string; last_name?: string; username?: string };

export function validateInitData(initData: string, botToken: string, maxAgeSeconds = 86_400): TelegramUser | null {
  if (!initData || !botToken) return null;
  const values = new URLSearchParams(initData);
  const suppliedHash = values.get("hash");
  const authDate = Number(values.get("auth_date"));
  const userJson = values.get("user");
  if (!suppliedHash || !userJson || !Number.isFinite(authDate) || Math.abs(Date.now() / 1000 - authDate) > maxAgeSeconds) return null;

  values.delete("hash");
  const checkString = [...values.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${key}=${value}`).join("\n");
  const secret = createHmac("sha256", "WebAppData").update(botToken).digest();
  const calculated = createHmac("sha256", secret).update(checkString).digest("hex");
  if (calculated.length !== suppliedHash.length || !timingSafeEqual(Buffer.from(calculated), Buffer.from(suppliedHash))) return null;
  try {
    const user = JSON.parse(userJson) as TelegramUser;
    return Number.isInteger(user.id) && typeof user.first_name === "string" ? user : null;
  } catch { return null; }
}

export async function telegramApi(token: string, method: string, payload: Record<string, unknown>): Promise<void> {
  await telegramApiResponse(token, method, payload);
}

export async function telegramApiResponse<T>(token: string, method: string, payload: Record<string, unknown>): Promise<T> {
  if (!token) throw new Error("Telegram token is not configured");
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload)
  });
  if (!response.ok) throw new Error(`Telegram ${method} failed (${response.status})`);
  const data = await response.json() as { ok: boolean, result: T };
  if (!data.ok) throw new Error(`Telegram ${method} returned an error`);
  return data.result;
}
