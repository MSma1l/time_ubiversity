export type WeekKind = "odd" | "even" | "every";

/**
 * The university's reference: 7–13 September 2026 is the even week.
 * Weeks start on Monday in the Europe/Chisinau timetable convention.
 */
export const SEMESTER_REFERENCE_MONDAY = "2026-09-07";

export function isoDateInChisinau(date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Chisinau", year: "numeric", month: "2-digit", day: "2-digit"
  }).format(date);
}

function mondayOf(isoDate: string): Date {
  const date = new Date(`${isoDate}T12:00:00Z`);
  const day = date.getUTCDay();
  date.setUTCDate(date.getUTCDate() - (day === 0 ? 6 : day - 1));
  return date;
}

export function universityWeekNumber(isoDate: string): number {
  const reference = mondayOf(SEMESTER_REFERENCE_MONDAY).getTime();
  const current = mondayOf(isoDate).getTime();
  return Math.floor((current - reference) / 604_800_000) + 1;
}

export function universityWeekKind(isoDate: string): Exclude<WeekKind, "every"> {
  return Math.abs(universityWeekNumber(isoDate)) % 2 === 0 ? "odd" : "even";
}

export function appliesInWeek(weekKind: WeekKind, isoDate: string): boolean {
  return weekKind === "every" || weekKind === universityWeekKind(isoDate);
}
